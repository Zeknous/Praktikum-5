<!DOCTYPE html>
<html>
	<head>
        <title>Latihan 1</title>
    </head>
	<body>
		Nama : <?php echo e($nama); ?> <br/>
		Asal : <?php echo e($asal); ?> <br/>
	</body>
</html><?php /**PATH C:\xampp\htdocs\latihan-5-laravel\resources\views/v_latihan1.blade.php ENDPATH**/ ?>