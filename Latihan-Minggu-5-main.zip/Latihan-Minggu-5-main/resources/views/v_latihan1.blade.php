<!DOCTYPE html>
<html>
	<head>
        <title>Latihan 1</title>
    </head>
	<body>
		Nama : {{$nama}} <br/>
		Asal : {{$asal}} <br/>
	</body>
</html>